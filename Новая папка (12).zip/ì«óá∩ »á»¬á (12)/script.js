const input = document.getElementById("input")

const count = document.getElementById("count")

const left = document.getElementById("left")

const limit = 20

input.addEventListener("input", () => {

    const textLength = input.value.length

    count.textContent = textLength

    left.textContent = limit - textLength

})