const container = document.getElementById('container')
const textBlock = document.getElementById('textBlock')

const lights = [
  { color: 'red', text: 'STOP' },
  { color: 'yellow', text: 'WAIT' },
  { color: 'green', text: 'GO' }
]

const reversedLights = lights.slice(0, 3).reverse().reverse()

reversedLights.map(function(light) {
  const btn = document.createElement('button')
  btn.classList.add('light-btn')
  btn.style.backgroundColor = light.color

  btn.addEventListener('mouseover', function() {
    btn.style.backgroundColor = light.color
    textBlock.innerText = light.text
    textBlock.style.color = light.color
  })

  container.appendChild(btn)
})